#Crear una aplicación que se ingrese por teclado el nombre de 5 empleados, sueldo cobrado por cada empleado en los ultimos 3 meses. Mostrar en pantalla el total pagado a cada empleado en los ultimos 3 meses obtener y mostrar cual fue el empleado de mayor ingreso.

arreglo = []
total = []
for x in range (5):
  persona = nombre = (input("Digite su nombre::\n")); monto= float(input("digite su monto en los ultimos 3 meeses:\n"))
  arreglo.append(persona)
  total.append(monto*3)

ganador = max(total)
print(arreglo)
print(total)
print (f'El sueldo mayor es:{ganador}')








