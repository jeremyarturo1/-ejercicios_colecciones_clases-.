#Crear una lista. La lista tiene que tener 3 elementos. Cada elemento debe ser una lista de 5 enteros. Calcular y mostrar la suma de cada lista contenida en la lista principal.

principal_lista = []
lista1=[]
lista2=[]
lista3=[]

for x in range (5):
  entero1=int(input(f'Digite su numero {x+1} para lista 1:'))
  lista1.append(entero1)
for x in range(5):
  entero2=int(input(f'Digite su numero {x+1} para lista 2: '))
  lista2.append(entero2)
for x in range(5):
  entero3=int(input(f'Digite su numero {x+1} para lista 3: '))
  lista3.append(entero3)

suma1=sum(lista1)
suma2=sum(lista2)
suma3=sum(lista3)
principal_lista.append(suma1)
principal_lista.append(suma2)
principal_lista.append(suma3)
suma_total_de_cada_lista = principal_lista
print(f'\nLa suma total es: {suma_total_de_cada_lista}.\n')


