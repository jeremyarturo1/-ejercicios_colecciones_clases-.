#Crear una función que le enviemos como parámetros dos enteros y nos retorne el mayor.
n1=int(input("Ingrese su primer numero:"))
n2=int(input("Ingrese el segundo numero:"))

def funcion (n1,n2): 
  
  if n1<n2:
    print(f"El mayor es el numero:{n2}")
  else:
    print(f"El mayor es el numero: {n1} ")

funcion(n1,n2)
