#Un programa que pida al usuario 4 números, los memorice (utilizando una coleccion), calcule su media aritmética y después muestre en pantalla la media y los datos ingresado.
arreglo = []

for x in range (4):
  num = int(input('Digite un numero:'))
  arreglo.append(num)
  
total = len(arreglo)
suma = sum(arreglo)
prom = (suma/total)

print(arreglo)
print(prom)