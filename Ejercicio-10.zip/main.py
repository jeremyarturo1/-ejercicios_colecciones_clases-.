#Crear una función que reciba una serie de edades y me retorne la cantidad que son mayores o iguales a 18.

arreglo = []
for x in range(10):
  edad=int(input('Introduzca su Edad:')) 
  if edad >= 18:
    arreglo.append(edad)
print(f'Las Edad aldutas: {arreglo}')