#Crear un programa que defina una lista de 5 elementos de tipo reales que representen las alturas de 5 personas. Obtener el promedio de las mismas. Contar cuántas personas son más altas que el promedio y cuántas más bajas.

alturas_5personas = []
promedio = 0
altura_mayor = 0 
altura_menor = 0

for x in range(5):
  alturas = float(input(f'Digite la altura de la {x} persona:'))
  promedio+=alturas
  alturas_5personas.append(alturas)
for x in range(5):
  if (alturas_5personas[x] > promedio/5):
    altura_mayor +=1

altura_menor =5 - altura_mayor

print (f'\n Hay {altura_mayor} personas con una altura mayor a la altura promedio y {altura_menor} personas con una altura menor a la promedio.\n ')