#Crear una lista y almacenar 20 enteros pedidos por teclado. Eliminar todos los elementos que sean pares.

arreglo = []
for x in range(0,20):
  num = int(input('Introuzca un numero: '))
  arreglo.append(num)
  if num % 2 == 0:
    arreglo.remove(num)

print(f"Numero impares son:{arreglo}")