#Crear y cargar una lista con 10 enteros por teclado. Crear un programa que identifique el valor mas pequeño de la lista y la posición donde se encuentra. Mostrar en pantalla el resultado.
arreglo = []
print('Digite 10 numeros: ')
for x  in range (10):
  num = int(input())
  arreglo.append(num)
num_peque = min(arreglo)
posicion = arreglo.index(num_peque)

print(f'El numero menor es:{num_peque}, y se encuentra en la posicion: {posicion}')