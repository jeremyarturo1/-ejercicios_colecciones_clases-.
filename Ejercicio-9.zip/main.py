#Crear una clase que permita ingresar valores enteros por teclado y nos muestre la tabla de multiplicar de dicho valor. Finalizar el programa al ingresar el -1.

valor=int(input('Introduzca un numero mayor que 0:'))

while valor > 0:
  tabla = int(input('Introduzca un numero para ver su tabla:\n'))
  if tabla == -1:
    print('Gracias por usarnos, pase buenas.')
    break
  else:
    for t in range(1,13):
      print(f'{t} x {tabla} = {t * tabla}')